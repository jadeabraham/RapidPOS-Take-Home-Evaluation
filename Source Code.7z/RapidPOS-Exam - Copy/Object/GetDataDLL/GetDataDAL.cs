﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using DAL;

namespace GetDataDLL
{
    public class GetDataDAL
    {
        public static GetDataDAL Instance { get { return new GetDataDAL(); } }
        public List<Dictionary<string, object>> GetSales_Hist(List<string> param)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("@START_DATE", param[0]);
            parameters.Add("@END_DATE", param[1]);
            return GetSQLDLL.Instance.ExecReader_Param("GetSales_Hist_Head", CommandType.StoredProcedure, parameters, false, 0);
        }
        public List<Dictionary<string, object>> GetSales_Hist_Line(List<string> param)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("@DocID", param[0]);
            return GetSQLDLL.Instance.ExecReader_Param("GetSales_Hist_Line", CommandType.StoredProcedure, parameters, false, 0);
        }
        public List<Dictionary<string, object>> GetTblStructure(List<string> param)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            return GetSQLDLL.Instance.ExecReader_Param("select * from INFORMATION_SCHEMA.COLUMNS where TABLE_NAME = '"+ param[0] + "'", CommandType.Text, parameters, false, 0);
        }
    }
}
