﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using System.Web;

namespace DAL
{
    public class GetSQLDLL
    {
        public static GetSQLDLL Instance { get { return new GetSQLDLL(); } }
        public string connectionstr = ConfigurationManager.ConnectionStrings["DemoGolfConn"].ConnectionString;
        private SqlConnection con;
        private SqlCommand cmd;
        private SqlDataReader reader;
        private SqlDataAdapter adapter;

        #region Initialize SqlConnection
        /// <summary>
        /// Initialize SqlConnection
        /// </summary>
        /// <returns></returns>
        private SqlConnection Connection()
        {
            con = new SqlConnection(connectionstr);
            return con;
        }
        #endregion
        #region Initialize SqlCommand
        /// <summary>
        /// Initialize SqlCommand
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        private SqlCommand Command(string query)
        {
            cmd = new SqlCommand(query, Connection());
            return cmd;
        }
        #endregion
        #region Dispose SqlConnection, SqlCommand, SqlDataReader
        /// <summary>
        /// Dispose SqlConnection, SqlCommand, SqlDataReader
        /// </summary>
        private void Dispose()
        {
            if (con != null) con.Dispose();

            if (cmd != null) cmd.Dispose();

            if (reader != null) reader.Dispose();
        }
        #endregion
        public DataTable DT_Return(string query, CommandType cmdType, Dictionary<string, object> parameters, bool hasnextresult, int timeOut = 30)
        {
            DataTable ret_dt = new DataTable();
            try
            {
                Command(query);

                cmd.CommandType = cmdType;

                foreach (var p in parameters)
                {
                    cmd.Parameters.Add(new SqlParameter(p.Key, p.Value));
                }
                con.Open();

                cmd.CommandTimeout = timeOut;

                reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Dictionary<string, object> r = new Dictionary<string, object>();
                    for (int c = 0; c < reader.FieldCount; c++)
                    {
                        if (reader.GetFieldType(c).ToString() == "System.Decimal")
                        {
                            if (reader.GetValue(c).ToString() == "")
                            {
                                r.Add(reader.GetName(c), "");
                            }
                            else
                            {
                                r.Add(reader.GetName(c), Convert.ToDouble(reader.GetValue(c)).ToString("#,###,###,##0.00"));
                            }
                        }
                        else if (reader.GetFieldType(c).ToString() == "System.DateTime")
                        {
                            if (reader.GetValue(c).ToString() == "")
                            {
                                r.Add(reader.GetName(c), reader.GetValue(c));
                            }
                            else
                            {
                                r.Add(reader.GetName(c), Convert.ToDateTime(reader.GetValue(c)).ToString());
                            }
                        }
                        else
                        {
                            if (reader.GetValue(c) == System.DBNull.Value)
                            {
                                r.Add(reader.GetName(c), "");
                            }
                            else
                            {
                                r.Add(reader.GetName(c), reader.GetValue(c));
                            }
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
            finally
            {
                Dispose();
            }
            return ret_dt;
        }
        public List<Dictionary<string, object>> ExecReader_Param(string query, CommandType cmdType, Dictionary<string, object> parameters, bool hasnextresult, int timeOut = 30)
        {
            List<Dictionary<string, object>> list = new List<Dictionary<string, object>>();
            try
            {
                Command(query);

                cmd.CommandType = cmdType;

                foreach (var p in parameters)
                {
                    cmd.Parameters.Add(new SqlParameter(p.Key, p.Value));
                }

                con.Open();

                cmd.CommandTimeout = timeOut;

                reader = cmd.ExecuteReader();

                if (hasnextresult == true)
                {
                    reader.NextResult();
                }

                while (reader.Read())
                {
                    Dictionary<string, object> r = new Dictionary<string, object>();
                    for (int c = 0; c < reader.FieldCount; c++)
                    {
                        if (reader.GetFieldType(c).ToString() == "System.Decimal")
                        {
                            if (reader.GetValue(c).ToString() == "")
                            {
                                r.Add(reader.GetName(c), "");
                            }
                            else
                            {
                                r.Add(reader.GetName(c), Convert.ToDouble(reader.GetValue(c)).ToString("#,###,###,##0.00"));
                            }
                        }
                        else if (reader.GetFieldType(c).ToString() == "System.DateTime")
                        {
                            if (reader.GetValue(c).ToString() == "")
                            {
                                r.Add(reader.GetName(c), reader.GetValue(c));
                            }
                            else
                            {
                                r.Add(reader.GetName(c), Convert.ToDateTime(reader.GetValue(c)).ToString());
                            }
                        }
                        else
                        {
                            if (reader.GetValue(c) == System.DBNull.Value)
                            {
                                r.Add(reader.GetName(c), "");
                            }
                            else
                            {
                                r.Add(reader.GetName(c), reader.GetValue(c));
                            }
                        }
                    }

                    list.Add(r);
                }
            }
            catch
            {
                throw;
            }
            finally
            {
                Dispose();
            }

            return list;
        }
    }
}
