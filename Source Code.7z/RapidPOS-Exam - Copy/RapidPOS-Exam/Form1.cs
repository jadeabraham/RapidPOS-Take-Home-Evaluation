﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using GetDataDLL;
using System.Globalization;
using static System.IO.Stream;
using System.IO;
using System.Web.Script.Serialization;
using System.Diagnostics;

namespace RapidPOS_Exam
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }
        private void btnGen_Click(object sender, EventArgs e)
        {
            DateTime.Parse(dateTimePicker1.Text.Trim()).ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
            string dFrom = string.Empty;
            dFrom = DateTime.Parse(dateTimePicker1.Text.Trim()).ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
            string dTo = string.Empty;
            dTo = DateTime.Parse(dateTimePicker2.Text.Trim()).ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);

            List<Dictionary<string, object>> SalesHist = new List<Dictionary<string, object>>();
            List<string> param = new List<string>();
            param.Add(dFrom);
            param.Add(dTo);
            SalesHist = GetSales_Hist(param);
            DataTable dt = new DataTable();
            dt.Columns.Add("Date");
            dt.Columns.Add("Branch");
            dt.Columns.Add("Doc_ID");
            dt.Columns.Add("Ticket_No");
            dt.Columns.Add("Tax_Amt");
            dt.Columns.Add("Qty_Sold");
            dt.Columns.Add("Total");
            for (int i = 0; i < SalesHist.Count; i++)
            {
                DataRow dr = dt.NewRow();
                dr["Date"] = Convert.ToDateTime(SalesHist[i]["BUS_DAT"]).ToShortDateString();
                dr["Branch"] = SalesHist[i]["STR_ID"].ToString();
                dr["Doc_ID"] = SalesHist[i]["DOC_ID"].ToString();
                dr["Ticket_No"] = SalesHist[i]["TKT_NO"].ToString();
                dr["Tax_Amt"] = SalesHist[i]["TAX_AMT"].ToString();
                dr["Qty_Sold"] = SalesHist[i]["soldQty"].ToString();
                dr["Total"] = SalesHist[i]["TOT"].ToString();
                dt.Rows.Add(dr);
            }
            dataGridView1.DataSource = dt;
            
            
        }
        public List<Dictionary<string, object>> GetSales_Hist(List<string> param)
        {
            return GetDataDAL.Instance.GetSales_Hist(param);
        }
        public List<Dictionary<string, object>> GetSales_Hist_Line(List<string> param)
        {
            return GetDataDAL.Instance.GetSales_Hist_Line(param);
        }
        public List<Dictionary<string, object>> GetTblStructure(List<string> param)
        {
            return GetDataDAL.Instance.GetTblStructure(param);
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            string varDocID = dataGridView1.SelectedCells[2].Value.ToString();
            List<Dictionary<string, object>> SalesHist_Line = new List<Dictionary<string, object>>();
            List<string> param = new List<string>();
            param.Add(varDocID);
            SalesHist_Line = GetSales_Hist_Line(param);
            DataTable dt = new DataTable();
            dt.Columns.Add("Line_Seq_No");
            dt.Columns.Add("Event_No");
            dt.Columns.Add("Ticket_No");
            dt.Columns.Add("Item_No");
            dt.Columns.Add("Description");
            dt.Columns.Add("Category");
            dt.Columns.Add("Sub_Category");
            dt.Columns.Add("Qty");
            dt.Columns.Add("Unit");
            dt.Columns.Add("Unit_Cost");
            dt.Columns.Add("Unit_Price");
            for (int i = 0; i < SalesHist_Line.Count; i++)
            {
                DataRow dr = dt.NewRow();
                dr["Line_Seq_No"] = SalesHist_Line[i]["LIN_SEQ_NO"];
                dr["Event_No"] = SalesHist_Line[i]["EVENT_NO"].ToString();
                dr["Ticket_No"] = SalesHist_Line[i]["TKT_NO"].ToString();
                dr["Item_No"] = SalesHist_Line[i]["ITEM_NO"].ToString();
                dr["Description"] = SalesHist_Line[i]["DESCR"].ToString();
                dr["Category"] = SalesHist_Line[i]["CATEG_COD"].ToString();
                dr["Sub_Category"] = SalesHist_Line[i]["SUBCAT_COD"].ToString();
                dr["Qty"] = SalesHist_Line[i]["QTY_SOLD"].ToString();
                dr["Unit"] = SalesHist_Line[i]["QTY_UNIT"].ToString();
                dr["Unit_Cost"] = SalesHist_Line[i]["UNIT_COST"].ToString();
                dr["Unit_Price"] = SalesHist_Line[i]["PRC"].ToString();
                dt.Rows.Add(dr);
            }
            dataGridView2.DataSource = dt;
        }

        public class WeatherForecast
        {
            public DateTimeOffset Date { get; set; }
            public int TemperatureCelsius { get; set; }
            public string Summary { get; set; }
        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            string filePath = string.Empty;
            using (var fbd = new FolderBrowserDialog())
            {
                DialogResult result = fbd.ShowDialog();

                if (result == DialogResult.OK && !string.IsNullOrWhiteSpace(fbd.SelectedPath))
                {
                    //string[] files = Directory.GetFiles(fbd.SelectedPath);
                    filePath = fbd.SelectedPath;
                }
            }
            DataTable dt = new DataTable();
            foreach (DataGridViewColumn col in dataGridView1.Columns)
            {
                dt.Columns.Add(col.Name);
            }

            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                DataRow dRow = dt.NewRow();
                foreach (DataGridViewCell cell in row.Cells)
                {
                    dRow[cell.ColumnIndex] = cell.Value;
                }
                dt.Rows.Add(dRow);
            }

            string dtToJSon = string.Empty;
            dtToJSon = DataTableToJSONWithJavaScriptSerializer(dt);

            File.WriteAllText(filePath + "\\JSonFile.json", dtToJSon);
            try
            {
                // code block for writing headers of data table

                int columnCount = dt.Columns.Count;
                string columnNames = "";
                string[] output = new string[dt.Rows.Count + 1];
                for (int i = 0; i < columnCount; i++)
                {
                    columnNames += dt.Columns[i].ToString() + ",";
                }
                output[0] += columnNames;

                // code block for writing rows of data table
                for (int i = 1; (i - 1) < dt.Rows.Count; i++)
                {
                    for (int j = 0; j < columnCount; j++)
                    {
                        output[i] += dt.Rows[i - 1][j].ToString() + ",";
                    }
                }

                System.IO.File.WriteAllLines(filePath + "\\test.csv", output, System.Text.Encoding.UTF8);
                MessageBox.Show("Check exported file in " + filePath + "\\test.csv");
                OpenFolder(filePath);
            }
            catch
            {

            }
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }
        public string DataTableToJSONWithJavaScriptSerializer(DataTable table)
        {
            JavaScriptSerializer jsSerializer = new JavaScriptSerializer();
            List<Dictionary<string, object>> parentRow = new List<Dictionary<string, object>>();
            Dictionary<string, object> childRow;
            foreach (DataRow row in table.Rows)
            {
                childRow = new Dictionary<string, object>();
                foreach (DataColumn col in table.Columns)
                {
                    childRow.Add(col.ColumnName, row[col]);
                }
                parentRow.Add(childRow);
            }
            return jsSerializer.Serialize(parentRow);
        }
        private void OpenFolder(string folderPath)
        {
            if (Directory.Exists(folderPath))
            {
                ProcessStartInfo startInfo = new ProcessStartInfo
                {
                    Arguments = folderPath,
                    FileName = "explorer.exe"
                };

                Process.Start(startInfo);
            }
            else
            {
                MessageBox.Show(string.Format("{0} Directory does not exist!", folderPath));
            }
        }
    }

}
